package com.listatarefas;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.List;

public class TarefaAdapter extends BaseAdapter {
    
    private Context context;
    private List<Tarefa> tarefas;
    private LayoutInflater inflater;
    
    public TarefaAdapter(Context context, List<Tarefa> tarefas) {
        this.context = context;
        this.tarefas = tarefas;
        this.inflater = LayoutInflater.from(context);
    }
    
    @Override
    public int getCount() {
        return tarefas.size();
    }
    
    @Override
    public Object getItem(int position) {
        return tarefas.get(position);
    }
    
    @Override
    public long getItemId(int position) {
        return tarefas.get(position).getId();
    }
    
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_tarefa, parent, false);
        }
        
        Tarefa tarefa = tarefas.get(position);
        
        TextView tvTitulo = convertView.findViewById(R.id.tvTitulo);
        TextView tvDescricao = convertView.findViewById(R.id.tvDescricao);
        TextView tvData = convertView.findViewById(R.id.tvData);
        
        tvTitulo.setText(tarefa.getTitulo());
        tvDescricao.setText(tarefa.getDescricao());
        tvData.setText(tarefa.getData());
        
        return convertView;
    }
}
