package com.listatarefas;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    
    private ListView listView;
    private LinearLayout btnAdd;
    private LinearLayout emptyView;
    private DatabaseHelper dbHelper;
    private TarefaAdapter adapter;
    private List<Tarefa> tarefas;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        dbHelper = new DatabaseHelper(this);
        
        listView = findViewById(R.id.listViewTarefas);
        btnAdd = findViewById(R.id.btnAdd);
        emptyView = findViewById(R.id.emptyView);
        
        // Garantir que o botão é clicável
        btnAdd.setClickable(true);
        listView.setClickable(true);
        carregarTarefas();
        
        // Clique normal no botão adicionar
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddTarefaActivity.class);
                startActivity(intent);
            }
        });
        
        //CLIQUE NORMAL na lista (já existente)
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mostrarOpcoes(tarefas.get(position));
            }
        });
        
        // CLIQUE LONGO na lista - NOVO!
        listView.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {
            
                @Override
                public boolean onItemLongClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                   Toast.makeText(MainActivity.this, "Clique feito", Toast.LENGTH_SHORT).show();
                    Tarefa tarefa = tarefas.get(position);
                    mostrarOpcoes(tarefa);
                    
                    return true;
               }
            });
            
    }
    
    private void carregarTarefas() {
        tarefas = dbHelper.getAllTarefas();
        
        if (tarefas.isEmpty()) {
            listView.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
        } else {
            listView.setVisibility(View.VISIBLE);
            emptyView.setVisibility(View.GONE);
            adapter = new TarefaAdapter(this, tarefas);
            listView.setAdapter(adapter);
        }
    }
    
    private void mostrarOpcoes(final Tarefa tarefa) {
        final String[] opcoes = {"✏️ Editar", "🗑️ Excluir"};
        
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(tarefa.getTitulo());
        builder.setItems(opcoes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    editarTarefa(tarefa);
                } else {
                    confirmarExclusao(tarefa);
                }
            }
        });
        builder.show();
    }
    
    private void editarTarefa(final Tarefa tarefa) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("✏️ Editar tarefa");
        
        final View view = getLayoutInflater().inflate(R.layout.activity_add_tarefa, null);
        final android.widget.EditText etTitulo = view.findViewById(R.id.etTitulo);
        final android.widget.EditText etDescricao = view.findViewById(R.id.etDescricao);
        
        etTitulo.setText(tarefa.getTitulo());
        etDescricao.setText(tarefa.getDescricao());
        
        builder.setView(view);
        builder.setPositiveButton("Salvar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String titulo = etTitulo.getText().toString().trim();
                String descricao = etDescricao.getText().toString().trim();
                
                if (!titulo.isEmpty()) {
                    dbHelper.updateTarefa(tarefa.getId(), titulo, descricao);
                    carregarTarefas();
                    Toast.makeText(MainActivity.this, "✅ Tarefa atualizada!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "⚠️ O título não pode estar vazio", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }
    
    private void confirmarExclusao(final Tarefa tarefa) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🗑️ Excluir tarefa");
        builder.setMessage("Tem certeza que deseja excluir \"" + tarefa.getTitulo() + "\"?");
        builder.setPositiveButton("Excluir", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dbHelper.deleteTarefa(tarefa.getId());
                carregarTarefas();
                Toast.makeText(MainActivity.this, "🗑️ Tarefa excluída!", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }
    
    // MÉTODOS PARA CLIQUE LONGO
    
    private void duplicarTarefa(Tarefa tarefa) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        String data = sdf.format(new Date());
        
        long id = dbHelper.addTarefa(
            tarefa.getTitulo() + " (cópia)",
            tarefa.getDescricao(),
            data
        );
        
        if (id != -1) {
            carregarTarefas();
            Toast.makeText(this, "📋 Tarefa duplicada!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "❌ Erro ao duplicar", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void copiarTitulo(Tarefa tarefa) {
        android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        android.content.ClipData clip = android.content.ClipData.newPlainText("titulo", tarefa.getTitulo());
        clipboard.setPrimaryClip(clip);
        Toast.makeText(this, "🔖 Título copiado para área de transferência!", Toast.LENGTH_SHORT).show();
    }
    
    private void excluirTarefaRapido(final Tarefa tarefa) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🗑️ Exclusão rápida");
        builder.setMessage("Excluir \"" + tarefa.getTitulo() + "\" sem confirmação?");
        builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dbHelper.deleteTarefa(tarefa.getId());
                carregarTarefas();
                Toast.makeText(MainActivity.this, "🗑️ Tarefa excluída rapidamente!", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Não", null);
        builder.show();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        carregarTarefas();
    }
}
